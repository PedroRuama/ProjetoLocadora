
package Telas;

import javax.swing.JFrame;

/**
 *
 * @author aluno
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame Login = new Login(); //Chama a janela LOGIN
        Login.setLocationRelativeTo(null);
        Login.setResizable(false);
        Login.setVisible(true);
      
    }

}
