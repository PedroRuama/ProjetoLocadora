
package Util;

import Tabelas.Veiculos;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class veiculosDAO {
    
    private Session sessao;
    
    public veiculosDAO () {
        
        this.sessao = HibernateUtil.getSessionFactory().openSession();
    }
    
    public void Salvar (Veiculos veiculos){
        Transaction t = sessao.beginTransaction();
        sessao.saveOrUpdate(veiculos);
        t.commit();
    }
    
     public void Editar(Veiculos veiculos){
        Transaction t = sessao.beginTransaction();
        sessao.update(veiculos);
        t.commit();
    }
     
      public void Excluir(Veiculos veiculos){
        Transaction t = sessao.beginTransaction();
        sessao.delete(veiculos);
        t.commit();
    }
}


